const FavouriteItem = () => {
    return(<div>
        Favourite item
    </div>)
}

export default FavouriteItem;