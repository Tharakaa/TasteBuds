const FavouriteOutlet = () => {
    return(<div>
        Favourite outlet
    </div>)
}

export default FavouriteOutlet;