import OutletCard from "./OutletCard";

const OutletList = () => {
  return (
    <>
      <div className="row">
        <div className="col-12 col-md-6 col-lg-4 col-xl-3">
          <OutletCard />
        </div>
      </div>
    </>
  );
};

export default OutletList;
