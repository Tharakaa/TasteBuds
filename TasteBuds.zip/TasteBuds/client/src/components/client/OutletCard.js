import { Link } from "react-router-dom";

const OutletCard = () => {
  return (
    <>
      <div>Outlet card</div>
      <button>
        <Link to="/outlet/1">View outlet</Link>
      </button>
    </>
  );
};

export default OutletCard;
