const User = require("../models/userModel.js")

const createUser = (req, res) => {
  res.send("WORKING");
};

module.exports = { createUser };
