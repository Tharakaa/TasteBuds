const express = require("express");
const { createUser } = require("../controllers/userController.js");
const authenticate = require("../middleware/authenticate.js");

const router = express.Router();

router.post("/register", authenticate, createUser);

module.exports = router;
